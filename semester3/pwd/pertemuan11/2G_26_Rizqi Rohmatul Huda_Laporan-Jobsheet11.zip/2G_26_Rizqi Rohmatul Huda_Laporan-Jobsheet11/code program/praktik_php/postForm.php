<html>
    <head>
    </head>
    <body>
        Selamat Datang <?php  echo $_POST["myname"]; ?> !!<br>
        Dari <?php echo $_POST["myaddress"]; ?>
    </body>
</html>