<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <h2> Indexed Array </h2>
        <?php
            $buah[0] = "Mangga";
            $buah[1] = "Apel";
            $buah[2] = "Jeruk"; 

            echo "Buah " . $buah[0]. " dan ". $buah[1] . " rasanya manis sekali";
        ?>
    </body>
</html>