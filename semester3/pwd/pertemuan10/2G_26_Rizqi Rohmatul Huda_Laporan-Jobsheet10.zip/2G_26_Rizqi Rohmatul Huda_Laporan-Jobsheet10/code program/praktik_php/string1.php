<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <?php
        echo strlen("hello world!");
        echo "<br>";
        echo str_word_count("hello world!");
        echo "<br>";
        echo strrev("hello world!");
        echo "<br>";
        echo strtoupper("hello world!");
        echo "<br>";
        echo strtolower("hello world!");
        echo "<br>";
        echo ucwords("hello world!");
        ?>
    </body>
</html>