<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <h3>Date</h3>
        <?php
        echo "Today is " . date("Y/m/d") . "<br>";
        echo "Today is " . date("Y.m.d") . "<br>";
        echo "Today is " . date("Y-m-d") . "<br>";
        echo "Today is " . date("-1");
        ?>
    </body>
</html>