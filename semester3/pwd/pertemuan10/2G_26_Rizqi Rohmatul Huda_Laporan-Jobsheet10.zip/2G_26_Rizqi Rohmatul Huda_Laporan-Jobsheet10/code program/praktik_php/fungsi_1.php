<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <h2>Fungsi</h2>
        <?php
        function writeMsh(){
            echo "Hello World";
        }
         writeMsh();
        ?>
    </body>
</html>