<html>
    <head>

    </head>
    <body>
        <h2> Fungsi </h2>
        <?php
            function writeMag(){
                echo "Hello World!";
            }

            writeMag();
        ?>
    </body>
</html>