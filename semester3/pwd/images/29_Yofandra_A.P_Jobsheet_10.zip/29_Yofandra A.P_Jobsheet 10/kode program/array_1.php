<html>
    <head>
    </head>
    <body>
        <h2> Indexed Array </h2>
        <?php
            $buah = array("Mangga", "Apel", "Jeruk");

            echo "Buah ". $buah[0]." dan ". " rasanya manis sekali";
        ?>
    </body>
</html>