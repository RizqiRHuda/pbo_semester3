package pemrogramanberbasisobjek.pertemuan11.project;

public interface Serviceable {
    public void service();
    public void repair(int a);
}

